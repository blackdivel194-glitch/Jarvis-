package com.jarvis.app.core;

import com.google.ai.client.generativeai.GenerativeModel;
import com.google.ai.client.generativeai.java.GenerativeModelFutures;
import com.google.ai.client.generativeai.type.Content;
import com.google.ai.client.generativeai.type.GenerateContentResponse;
import com.google.common.util.concurrent.FutureCallback;
import com.google.common.util.concurrent.Futures;
import com.google.common.util.concurrent.ListenableFuture;
import com.jarvis.app.BuildConfig;

import java.util.concurrent.Executor;

public class JarvisBrain {

    private final GenerativeModel generativeModel;
    private final Executor executor;

    public JarvisBrain(Executor executor) {
        this.executor = executor;
        generativeModel = new GenerativeModel("gemini-pro", BuildConfig.GEMINI_API_KEY);
    }

    public interface BrainCallback {
        void onSuccess(String response);
        void onError(Throwable throwable);
    }

    public void getResponse(String query, BrainCallback callback) {
        Content content = new Content.Builder().addText(query).build();
        GenerativeModelFutures modelFutures = GenerativeModelFutures.from(generativeModel);
        ListenableFuture<GenerateContentResponse> response = modelFutures.generateContent(content);

        Futures.addCallback(response, new FutureCallback<GenerateContentResponse>() {
            @Override
            public void onSuccess(GenerateContentResponse result) {
                String responseText = result.getText();
                callback.onSuccess(responseText);
            }

            @Override
            public void onFailure(Throwable t) {
                callback.onError(t);
            }
        }, executor);
    }
}
