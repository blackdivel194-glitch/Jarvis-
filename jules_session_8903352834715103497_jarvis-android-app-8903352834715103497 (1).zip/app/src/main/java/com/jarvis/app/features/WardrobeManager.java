package com.jarvis.app.features;

import android.content.Context;

public class WardrobeManager {

    private final Context context;

    public WardrobeManager(Context context) {
        this.context = context;
    }

    public void getOutfitSuggestion() {
        // TODO: Implement logic to suggest an outfit based on stored wardrobe data
        // TODO: Implement UI to display the suggestion in a rectangular card
    }
}
